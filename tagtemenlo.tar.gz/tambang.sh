#!/bin/sh
./noa -a ethash -o stratum+tcp://daggerhashimoto.usa-east.nicehash.com:3353 -u 3J9SuUt6GuPWEgwYY72XEwK4dHeGQxdJMu -p x -w tagtemenloyanggokil --low-load 1
